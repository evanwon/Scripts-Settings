﻿using System;
using System.Collections.Generic;
using Moq;
using NUnit.Framework;

namespace $rootnamespace$
{
    /// <summary>
    /// NUnit TestFixture providing unit test coverage of <see cref="TestTarget"/>.
    /// </summary>
    
    public class $safeitemname$
    {
        [TestFixture]
        public class MethodName
        {
        
        }

        [TestFixture]
        public class TestContext
        {
            
        }
    }
}
