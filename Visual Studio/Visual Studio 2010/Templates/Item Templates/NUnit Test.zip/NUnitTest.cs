﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using Rhino.Mocks;

namespace $rootnamespace$
{
	/// <summary>
	/// NUnit TestFixture providing unit test coverage of <see cref="$safeitemname$"/>.
	/// </summary>
	[TestFixture]
	public class $safeitemname$
	{
		#region Member Variables



		#endregion

		#region TestFixture Setup / Teardown

		/// <summary>
		/// Default constructor.
		/// </summary>
		public $safeitemname$()
		{
			//TODO: Add any readonly member initialization here...
		}

		#endregion

		#region Test Methods



		#endregion

		#region Private Methods



		#endregion
	}
}
