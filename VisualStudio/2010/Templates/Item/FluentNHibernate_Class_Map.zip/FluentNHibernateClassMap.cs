﻿using FluentNHibernate.Mapping;

namespace $rootnamespace$
{
    /// <summary>
    /// FluentNHibernate <see cref="T" /> class map.
    /// </summary>
    public class $safeitemname$ : ClassMap<T>
    {
        public $safeitemname$()
        {
            Table("table_name");

            Id(p => p.Id);

            //Map(p => p.Name);
			//Map(p => p.Website).CustomType<UriUserType>();
        }
    }
}
